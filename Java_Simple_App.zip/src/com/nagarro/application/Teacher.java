package com.nagarro.application;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Teacher extends Person {
	//employeeId Salary	Bonus

	private String t_employeeId;
	private double t_salary;
	private double t_bonus;
	private String teacherData;

	public Teacher() throws SchoolDataException {
		super.getPersonDetails();
		getDetails();
	}
	
	
	private void getDetails() {

		Scanner t_dataScan = new Scanner(System.in);

		System.out.print("Enter employee id : ");
		t_employeeId = t_dataScan.nextLine();

		System.out.print("Enter salary : ");
		t_salary = t_dataScan.nextDouble();
		
		System.out.print("Enter bonus : ");
		t_bonus = t_dataScan.nextDouble();

		teacherData = super.toString() + ", Table= Teacher" + ", Employee Id= " + t_employeeId + ", Salary= " + t_salary + ", Bonus= "+t_bonus;

		//t_dataScan.close();
	}
	
	@Override
	public void addDetails() {

		//tmp_schoolDb.put(super.p_firstName, teacherData);
		try {
			BufferedWriter writer = new BufferedWriter(new FileWriter(file,true));
			writer.write("\n"+teacherData);
			writer.close();
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println("Data saved to db.");
	}
}
