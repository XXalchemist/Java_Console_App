/**
 * 
 */
package com.nagarro.application;

import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 * @author narayankrishna
 *
 */
public class Runner {
	private static Scanner runnerScan = new Scanner(System.in);
	public static void main(String[] args) throws FileNotFoundException, SchoolDataException {
		int numberOfTries = 4;


		// password matching
		while(numberOfTries > 0) {
			System.out.print("Enter the password : ");
			String inputPassword = runnerScan.nextLine();
			if(PasswordManagement.verifyPassword(inputPassword)) {
				return;
			};
			System.out.println("Left retries : "+(numberOfTries-1));
			numberOfTries--;
			if (numberOfTries==0) {
				System.out.println("Application exited as no retries left .");
			}
		}
	}

}
