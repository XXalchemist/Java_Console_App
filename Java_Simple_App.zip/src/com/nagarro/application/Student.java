package com.nagarro.application;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Student extends Person {

	private int s_rollNumber;
	private double s_marks;
	private String studentData;
	//private static Scanner data_scan = new Scanner(System.in);
	
	public Student() throws SchoolDataException {
		super.getPersonDetails();
		getDetails();
	}

	private void getDetails() {

		Scanner s_dataScan = new Scanner(System.in);

		System.out.print("Enter Roll number : ");
		s_rollNumber = s_dataScan.nextInt();

		System.out.print("Enter Marks : ");
		s_marks = s_dataScan.nextDouble();

		studentData = super.toString() + ", Table= Student" + ", RollNumber= " + s_rollNumber + ", Marks= " + s_marks;

		//data_scan.close();

	}

	// store student details with firstname as key, to delete the data easily
	@Override
	public void addDetails() {

		//tmp_schoolDb.put(super.p_firstName, studentData) ;
		try {
			BufferedWriter writer = new BufferedWriter(new FileWriter(file,true));
			writer.write("\n"+studentData);
			writer.close();
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println("Data saved to db.");
	}

}
