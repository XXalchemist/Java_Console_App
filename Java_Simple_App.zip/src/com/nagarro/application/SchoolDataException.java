package com.nagarro.application;

public class SchoolDataException extends Exception {
	
	public SchoolDataException(String message) {
		
		super(message);
	}
}
