package com.nagarro.application;

import java.util.Scanner;

public class MainMenu {
	
	private static Scanner mainMenuScan = new Scanner (System.in);
	
	// Main Display options
	public static void mainMenuOptions() throws SchoolDataException {

		while(true) {
			try {
				System.out.print("Enter your choice :- \n"
						+ "1. Add Student Details\n"
						+ "2. Remove Student Detail\n"
						+ "3. Add Teacher Details\n"
						+ "4. Remove Teacher Detail\n"
						+ "5. Query Data\n"
						+ "6. Exit\n=> ");

				String choice =  mainMenuScan.nextLine();
				choice = choice.replaceAll(" ", "");

				if (choice.equals("1")) {
					// add student details
					Person newStudent = new Student();
					newStudent.addDetails();
				}

				else if (choice.equals("2")) {
					//System.out.println(choice);
					removePersonDetailsOption("Student");
				}

				else if (choice.equals("3")) {
					//System.out.println(choice);
					Person newTeacher = new Teacher();
					newTeacher.addDetails();

				}
				else if (choice.equals("4")) {
					//System.out.println(choice);
					removePersonDetailsOption("Teacher");
				}
				else if (choice.equals("5")) {

					showDataByQueryOption();
					//Person.showDetails("Student");
				}
				else if (choice.equals("6")) {

					//Person.showDetailsFromFile();
					System.out.println("Application exited successfully .");
					System.exit(0);

				}
				else {
					System.out.println("Entered Choice is invalid , please try again ...");

				}
			}catch(Exception e) {
				System.out.println("Exception : "+e.getMessage());	
			}
		}
	}

	// query method
	private static void showDataByQueryOption() throws Exception {

		//Scanner inputQueryScan = new Scanner(System.in);
		System.out.print("Enter the query : ");
		String queryString =  mainMenuScan.nextLine();

		if(!queryValidation(queryString))
			throw new Exception("Invalid query !!!");

		else {
			queryString = queryString.replaceAll(" ","").toLowerCase();
			//System.out.print(queryString);
			if(queryString.equals("select*fromstudent"))
				Person.showDetailsFromFile("Student");

			else if(queryString.equals("select*fromteacher"))
				Person.showDetailsFromFile("Teacher");

			else if(queryString.equals("select*fromperson"))
				Person.showDetailsFromFile("Person");
		}
	}

	// Select*From$tableName
	private static boolean queryValidation(String queryStringData) {
		String[] queryWords = queryStringData.split(" ");

		if (queryWords.length !=4)
			return false;

		else if((queryWords[0].toLowerCase().equals("select")) && (queryWords[1].equals("*")) && (queryWords[2].toLowerCase().equals("from"))) {

			if ((queryWords[3].toLowerCase().equals("person")) || (queryWords[3].toLowerCase().equals("student")) || (queryWords[3].toLowerCase().equals("teacher")))

				return true;
			else

				return false;
		}
		else

			return false;
	}

	// remove person main menu option
	private static void removePersonDetailsOption(String optionName) throws Exception {

		//Scanner searchStringScan = new Scanner(System.in);
		String searchString;
		if(optionName.equals("Student")) {
			System.out.print("Enter the "+ optionName + " RollNumber : ");
			searchString=  mainMenuScan.nextLine();
			Person.removePersonDetailsFromFile("RollNumber= "+searchString);

		}
		else if(optionName.equals("Teacher")) {
			System.out.print("Enter the "+ optionName + " Employee Id : ");
			searchString=  mainMenuScan.nextLine();
			Person.removePersonDetailsFromFile("Employee Id= "+searchString);

		}

		//searchStringScan.close();
	}
}
