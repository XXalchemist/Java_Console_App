package com.nagarro.application;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class Person {

	private String name;
	private long p_contactNumber;
	private String p_address;
	private String p_middleName;
	private String p_lastName;
	private String p_firstName;

	// stores student and teacher details
	protected static String tmp_schoolDb = null;;
	private static List<String> filteredPersonData = null;
	protected static File file = new File(".\\resources\\db.txt");

	// scanner to take input
	//protected static Scanner data_scan = new Scanner(System.in);

	protected void getPersonDetails() throws SchoolDataException {

		Scanner p_dataScan = new Scanner(System.in);

		System.out.print("Enter first name : ");
		p_firstName = p_dataScan.nextLine();

		System.out.print("Enter middle name : ");
		p_middleName = p_dataScan.nextLine();

		System.out.print("Enter last name : ");
		p_lastName = p_dataScan.nextLine();

		name = p_firstName + " " + p_middleName + " " + p_lastName;

		System.out.print("Enter address : ");
		p_address = p_dataScan.nextLine();

		System.out.print("Enter contact number : ");
		p_contactNumber = p_dataScan.nextLong();
		mobileNumberVerification(p_contactNumber);

		//p_dataScan.close();
	}

	protected void addDetails() {

	}

	public static void showDetailsFromFile(String tableName) throws IOException {

		BufferedReader reader = new BufferedReader(new FileReader(file));

		if(reader.readLine() == null)
			System.out.println("No data stored in db, please add some entries.");

		// shows person data
		else { 

			System.out.println("---------------------------------------------------------------------------------------------------------------------");
			//System.out.println(reader.lines().toString());

			// if any data is exist then it will be person
			if (tableName.toLowerCase().equals("person")) {
				reader.lines().forEach((personData)-> System.out.println(personData));
			}
			else if(tableName.toLowerCase().equals("student") || tableName.toLowerCase().equals("teacher")) {
				filteredPersonData = reader.lines().filter(e->e.contains("Table= "+tableName)).collect(Collectors.toList());

				if(filteredPersonData.isEmpty())
					System.out.println(tableName+" table has no records.");

				else {
					filteredPersonData.forEach(personData -> System.out.println(personData.replace(", Table= "+tableName, "")));
				}
			}
			reader.close();
			System.out.println();
			System.out.println("---------------------------------------------------------------------------------------------------------------------");
		}
	}

	public static void removePersonDetailsFromFile(String searchString) throws Exception {

		BufferedReader reader = new BufferedReader(new FileReader(file));
		BufferedReader reader_tmp_schoolDb = new BufferedReader(new FileReader(file));
		
		tmp_schoolDb = reader.lines().filter(personData -> !personData.contains(searchString)).collect(Collectors.joining()).replaceAll("Name", "\nName");
		
		boolean personExist = reader_tmp_schoolDb.lines().anyMatch(personData -> personData.contains(searchString));
		//System.out.println(personExist);
		//System.out.print("tmp db : "+tmp_schoolDb);
		reader_tmp_schoolDb.close();
		reader.close();

		if(!personExist)
			System.out.println("Can't delete person data as it does not exists in db.");
		
		else {
		// get remaining person data
		BufferedWriter writer = new BufferedWriter(new FileWriter(file));
		writer.write(tmp_schoolDb);
		System.out.println("Person data deleted successfully.");
		writer.close();
		}
	}

	private void mobileNumberVerification(long mobileNumber) throws SchoolDataException {

		int count = 0;  
		while(mobileNumber != 0)  
		{  
			// removing the last digit of the number n  
			mobileNumber = mobileNumber / 10;    
			count = count + 1;  
		}  
		if(count != 10)
			throw new SchoolDataException("Invalid mobile number ...");
	}


	public String toString()
	{
		return "Name= " + name + ", Contact Number= " + p_contactNumber + ", Address= " + p_address;
	}
}


//	public static void showDetails(String tableName) {
//
//		if(tmp_schoolDb.isEmpty())
//			System.out.println("No data stored in db, please add some entries.");
//
//		else { 
//
//			System.out.println("---------------------------------------------------------------------------------------------------------------------");
//			System.out.println();
//			if (tableName.toLowerCase().equals("person"))
//				tmp_schoolDb.forEach((personFirstName, personData)-> System.out.println(personData));
//
//			else if(tableName.toLowerCase().equals("student") || tableName.toLowerCase().equals("teacher")) {
//
//				filteredPersonData  = tmp_schoolDb.values().stream().filter(e->e.contains("Table= "+tableName)).collect(Collectors.toList());
//				if(filteredPersonData.isEmpty())
//					System.out.println(tableName+" table has no records.");
//				else {
//
//					filteredPersonData.forEach(personData->
//					System.out.println(personData.replace(", Table= "+tableName, "")));
//				}
//			}
//			System.out.println();
//			System.out.println("---------------------------------------------------------------------------------------------------------------------");
//		}
//	}

//  delete person data from tmp_schoolDb
//	public static void removePerson(String personFirstName) {
//
//		if(tmp_schoolDb.containsKey(personFirstName)) {
//			tmp_schoolDb.remove(personFirstName);
//			System.out.println(personFirstName+ " data removed from db.");
//		}
//		else
//			System.out.println(personFirstName+ " data not found in db.");
//	}

// delete person details from file
