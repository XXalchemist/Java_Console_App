package com.nagarro.application;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class PasswordManagement {

	public static boolean verifyPassword(String inputPasswordValue) throws FileNotFoundException, SchoolDataException {
		Scanner passwordFileScan = new Scanner (new File(".\\resources\\passwords.txt"));
		boolean passwordFound = false;

		while (passwordFileScan.hasNextLine()) {
			String password = passwordFileScan.nextLine();
			//System.out.println(password);

			// condition when password matches
			if (password.equals(inputPasswordValue)) {
				passwordFound = true;
				System.out.println("Login Succesfully ...");
				System.out.println("****************************** School Data Simple Query System ******************************");
				MainMenu.mainMenuOptions();
				System.out.println("****************************** ------------------------------- ******************************");
			} 
		}

		// condition when password doesn't matches
		if(!passwordFound) { 
			System.out.println("Wrong Password !!!");
		}

		// close the file scanner
		passwordFileScan.close();
		return passwordFound;
	}
	
}
